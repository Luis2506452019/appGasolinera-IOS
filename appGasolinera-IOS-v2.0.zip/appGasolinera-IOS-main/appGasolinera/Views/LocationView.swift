//
//  LocationView.swift
//  appGasolinera
//
//  Created by MacOsX on 11/5/23.
//

import SwiftUI

struct LocationView: View {
    var body: some View {
        Text("Contenido de Ubicacion")
            .font(.title)
            .padding()
    }
}

struct LocationView_Previews: PreviewProvider {
    static var previews: some View {
        LocationView()
    }
}
